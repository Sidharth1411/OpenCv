from django.apps import AppConfig


class FaceConfig(AppConfig):
    name = 'face'
